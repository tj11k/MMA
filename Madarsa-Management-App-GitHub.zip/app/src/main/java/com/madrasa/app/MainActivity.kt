package com.madrasa.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.container)
        showLogin()
    }

    private fun base(title: String, subtitle: String? = null) {
        container.removeAllViews()
        val titleView = TextView(this).apply {
            text = title
            textSize = 28f
            setTextColor(Color.rgb(0,105,92))
            setTypeface(null, 1)
            setPadding(0, 10, 0, 4)
        }
        container.addView(titleView)
        subtitle?.let {
            container.addView(TextView(this).apply {
                text = it; textSize = 14f; setPadding(0,0,0,18)
            })
        }
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply { this.text = text; setOnClickListener { action() } }

    private fun showLogin() {
        base("Madarsa Management", "Secure role-based access")
        val mobile = EditText(this).apply {
            hint = "Mobile number / Email"; inputType = 33
        }
        val pass = EditText(this).apply {
            hint = "Password"; inputType = 129
        }
        container.addView(mobile); container.addView(pass)
        container.addView(button("LOGIN") {
            showRoleChooser()
        })
        container.addView(TextView(this).apply {
            text = "Demo build: choose a portal after login."
            setPadding(0,20,0,0)
        })
    }

    private fun showRoleChooser() {
        base("Select Portal", "Demo navigation — production login will use Supabase Auth")
        container.addView(button("Student Portal") { studentHome() })
        container.addView(button("Staff Portal") { staffHome() })
        container.addView(button("Admin Portal") { adminHome() })
    }

    private fun studentHome() {
        base("Student Portal", "Ahmed Khan • Class 5-A")
        listOf(
            "📊 My Attendance" to {"simple("Attendance", "Present: 23   Absent: 1   Leave: 1   Attendance: 92%", ::studentHome)"},
            "📝 Daily Report" to {"simple("Daily Report", "Today's report and teacher remarks appear here.", ::studentHome)"},
            "🕌 Hifz Tracking" to {"simple("Hifz Tracking", "Sabaq • Sabqi • Manzil • Revision • Teacher Remarks", ::studentHome)"},
            "🏆 Results" to {"simple("Results", "Exam-wise marks, percentage, grade and report card.", ::studentHome)"},
            "📨 Leave Request" to {"simple("Leave Request", "Create and track your leave requests.", ::studentHome)"},
            "🗓 Timetable" to {"simple("Timetable", "Today's and weekly class schedule.", ::studentHome)"},
            "📢 Notices" to {"simple("Notices", "General and class announcements.", ::studentHome)"},
            "👤 Profile" to {"simple("Profile", "Personal and academic profile. Corrections can be requested.", ::studentHome)"}
        ).forEach { (t, a) -> container.addView(button(t, a)) }
        container.addView(button("Logout") { showLogin() })
    }

    private fun staffHome() {
        base("Staff Portal", "Umar Farooq • Assigned Classes")
        listOf(
            "👥 My Classes" to {"simple("My Classes", "Only classes assigned by Admin are visible.", ::staffHome)"},
            "✅ Student Attendance" to {"simple("Student Attendance", "Mark All Present • Present • Absent • Leave • Late • Half Day • Save Draft • Submit", ::staffHome)"},
            "📝 Daily Report" to {"simple("Daily Report", "Update assigned students' daily learning/performance reports.", ::staffHome)"},
            "🕌 Hifz Tracking" to {"simple("Hifz Tracking", "Update Sabaq, Sabqi, Manzil, revision and remarks.", ::staffHome)"},
            "👤 My Attendance" to {"simple("My Attendance", "View your daily/monthly attendance history.", ::staffHome)"},
            "💰 My Salary" to {"simple("My Salary", "View salary, LOP days, deductions, net salary and payslip.", ::staffHome)"},
            "🗓 Timetable" to {"simple("Timetable", "Your teaching schedule.", ::staffHome)"},
            "📢 Notices" to {"simple("Notices", "Staff announcements from Admin.", ::staffHome)"}
        ).forEach { (t, a) -> container.addView(button(t, a)) }
        container.addView(button("Logout") { showLogin() })
    }

    private fun adminHome() {
        base("Admin Portal", "Madarsa Command Center")
        listOf(
            "📊 Dashboard" to {"simple("Dashboard", "Students: 850 • Staff: 42 • Today's Attendance: 94% • Pending Leaves: 12 • Pending Reports: 7", ::adminHome)"},
            "👨‍🎓 Students" to {"simple("Student Management", "Add • View • Edit • Assign Class • Activate/Deactivate • Archive", ::adminHome)"},
            "👨‍🏫 Staff" to {"simple("Staff Management", "Add • Edit • Assign Classes/Subjects • Salary • Permissions • Activate/Deactivate • Archive", ::adminHome)"},
            "🏫 Classes & Subjects" to {"simple("Classes & Subjects", "Create/edit/archive classes, sections and subjects; assign teachers and students.", ::adminHome)"},
            "✅ Attendance" to {"simple("Attendance Management", "Student/staff attendance, verification, correction requests and locking.", ::adminHome)"},
            "📝 Daily Reports" to {"simple("Daily Reports", "Submitted/pending reports, date/class/student filters.", ::adminHome)"},
            "🕌 Hifz Tracking" to {"simple("Hifz Management", "View and manage student Sabaq, Sabqi, Manzil, revision and teacher remarks.", ::adminHome)"},
            "📨 Leave Management" to {"simple("Leave Management", "Approve/reject student or staff leave; mark paid or LOP.", ::adminHome)"},
            "📝 Exams & Results" to {"simple("Exams & Results", "Create exams, enter/review marks, publish/unpublish results.", ::adminHome)"},
            "🗓 Timetable" to {"simple("Timetable", "Create schedules and detect teacher/class conflicts.", ::adminHome)"},
            "📢 Notices" to {"simple("Notice Management", "Create, target, publish, edit, unpublish and archive notices.", ::adminHome)"},
            "💰 Payroll" to {"simple("Payroll", "Calculate salary from attendance/leave, review, approve, finalise and generate payslips.", ::adminHome)"},
            "📈 Reports & Analytics" to {"simple("Reports", "Attendance, daily reports, leaves, exams, results and payroll reports.", ::adminHome)"},
            "🔐 Permissions" to {"simple("Roles & Permissions", "Control exactly what each staff role can view/change.", ::adminHome)"},
            "🕵 Activity Log" to {"simple("Activity Log", "Who changed what and when; especially attendance, results and payroll.", ::adminHome)"},
            "⚙ Settings" to {"simple("Settings", "Madarsa details, academic year, attendance, leave, payroll and system settings.", ::adminHome)"},
            "🆘 Help Centre" to {"helpCentre()"}
        ).forEach { (t, a) -> container.addView(button(t, a)) }
        container.addView(button("Logout") { showLogin() })
    }

    private fun helpCentre() {
        base("Help Centre", "Admin-only step-by-step guide")
        val topics = listOf(
            "1. Add a Student" to "Students → + Add Student → enter details → Assign Class/Section → Save.",
            "2. Add a Teacher" to "Staff → + Add Staff → create account → assign class/subject → set permissions.",
            "3. Mark Attendance" to "Teacher: My Classes → Class → Attendance → Mark All Present → correct exceptions → Save/Submit.",
            "4. Manage Hifz" to "Teacher: Hifz Tracking → Student → update Sabaq/Sabqi/Manzil/Revision → Save. Student sees published history.",
            "5. Approve Leave" to "Leaves → Pending → View → Approve/Reject. For staff, choose Paid Leave or LOP where applicable.",
            "6. Publish Results" to "Exams & Results → select exam/class → enter/review marks → Publish. Published results are protected.",
            "7. Run Payroll" to "Payroll → select month → Calculate → review attendance/LOP → Approve → Finalise → Payslip.",
            "8. Fix a Mistake" to "Use Correction/Approval instead of silently changing locked records. The Activity Log records important changes.",
            "9. Send Notice" to "Notices → + New Notice → choose audience → write message → Publish.",
            "10. Permissions" to "Settings → Roles & Permissions → allow only the screens/actions a staff member needs."
        )
        topics.forEach { (h,b) ->
            val box = TextView(this).apply {
                text = "$h\n$b"; textSize = 16f; setPadding(8,16,8,16)
            }
            container.addView(box)
        }
        container.addView(button("← Back to Admin") { adminHome() })
    }

    private fun simple(title: String, body: String, back: () -> Unit) {
        base(title)
        container.addView(TextView(this).apply {
            text = body; textSize = 17f; setPadding(0,10,0,24)
        })
        container.addView(button("← Back") { back() })
    }
}
