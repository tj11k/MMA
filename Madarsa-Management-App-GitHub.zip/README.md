# Madarsa Management App

Android starter build for a role-based Madrasa Management System.

## Current demo
- Login screen
- Student Portal
- Staff Portal
- Admin Portal
- Student attendance view
- Leave request area
- Daily reports
- Hifz tracking area
- Results
- Timetable
- Notices
- Staff attendance/salary areas
- Admin management areas
- Admin-only Help Centre
- GitHub Actions APK build workflow

## Important
This first APK is a functional UI/navigation prototype. Supabase cloud authentication and database wiring must be configured before using it with real madrasa data.

The production architecture should use Supabase/PostgreSQL with Row Level Security so:
- students can read only their own records
- teachers can work only on assigned classes/students
- admins can manage the institution

Never put a Supabase service-role key inside the Android app.
