# MadarsaApp — Supabase Connected

Supabase project URL: https://lqccpcdswarxatpvpayj.supabase.co

The app uses the Supabase **publishable** key only. Do not add a service-role/secret key to the Android app.

Database modules created:
- Profiles / roles
- Students and guardians
- Staff / teachers
- Classes, subjects, academic years, enrollments
- Student and staff attendance
- Daily reports and Hifz tracking
- Leave requests
- Exams and results
- Timetable and notices
- Fee structures, student fees, payments
- Payroll and staff permissions
- Activity logs

The current Android UI has:
- Supabase email/password login
- Account creation
- Role-aware portal selection
- Supabase profile lookup
- Existing Admin / Staff / Student portal UI

Important: the first created account defaults to the `student` role. Promote the intended administrator account to `admin` only after its email is known and verified. Never expose a service-role key in the APK.
