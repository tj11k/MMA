package com.madarsa.app;

import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class SupabaseClient {
    public static final String SUPABASE_URL = "https://lqccpcdswarxatpvpayj.supabase.co";
    public static final String SUPABASE_PUBLISHABLE_KEY = "sb_publishable_RmKBFxVKmrtS_r4-NGWCqw_TCqm_VAx";

    public static class AuthResult {
        public boolean ok; public String accessToken; public String userId; public String message;
        AuthResult(boolean ok,String token,String uid,String msg){this.ok=ok;accessToken=token;userId=uid;message=msg;}
    }

    public static AuthResult login(String email, String password) throws Exception {
        JSONObject body=new JSONObject();
        body.put("email",email); body.put("password",password);
        HttpURLConnection c=(HttpURLConnection)new URL(SUPABASE_URL+"/auth/v1/token?grant_type=password").openConnection();
        c.setRequestMethod("POST"); c.setRequestProperty("apikey",SUPABASE_PUBLISHABLE_KEY);
        c.setRequestProperty("Content-Type","application/json"); c.setDoOutput(true);
        try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
        String text=read(c); JSONObject r=new JSONObject(text);
        if(c.getResponseCode()>=200 && c.getResponseCode()<300)
            return new AuthResult(true,r.optString("access_token"),r.optJSONObject("user").optString("id"),"Login successful");
        return new AuthResult(false,null,null,r.optString("msg",r.optString("error_description","Login failed")));
    }

    public static AuthResult signUp(String email,String password,String name) throws Exception {
        JSONObject body=new JSONObject(); body.put("email",email); body.put("password",password);
        JSONObject meta=new JSONObject(); meta.put("full_name",name); body.put("data",meta);
        HttpURLConnection c=(HttpURLConnection)new URL(SUPABASE_URL+"/auth/v1/signup").openConnection();
        c.setRequestMethod("POST"); c.setRequestProperty("apikey",SUPABASE_PUBLISHABLE_KEY);
        c.setRequestProperty("Content-Type","application/json"); c.setDoOutput(true);
        try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
        String text=read(c); JSONObject r=new JSONObject(text);
        if(c.getResponseCode()>=200 && c.getResponseCode()<300)
            return new AuthResult(true,r.optString("access_token"),r.optJSONObject("user")!=null?r.optJSONObject("user").optString("id"):null,"Account created. Check email if verification is required.");
        return new AuthResult(false,null,null,r.optString("msg",r.optString("error_description","Sign up failed")));
    }

    public static JSONObject getProfile(String token) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(SUPABASE_URL+"/rest/v1/profiles?select=id,full_name,role,staff_id,student_id,active&limit=1").openConnection();
        c.setRequestMethod("GET"); c.setRequestProperty("apikey",SUPABASE_PUBLISHABLE_KEY);
        c.setRequestProperty("Authorization","Bearer "+token);
        c.setRequestProperty("Accept","application/json");
        String text=read(c); if(c.getResponseCode()<200 || c.getResponseCode()>=300) throw new Exception(text);
        org.json.JSONArray a=new org.json.JSONArray(text);
        return a.length()>0?a.getJSONObject(0):new JSONObject();
    }

    private static String read(HttpURLConnection c) throws Exception {
        InputStream in=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream();
        if(in==null)return "";
        try(BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){
            StringBuilder s=new StringBuilder(); String line; while((line=br.readLine())!=null)s.append(line); return s.toString();
        }
    }
}