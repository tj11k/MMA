package com.madarsa.app;

import android.os.Bundle;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;
import org.json.JSONObject;
import androidx.appcompat.app.AppCompatActivity;
import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity {
    LinearLayout root, content;
    int green=Color.rgb(11,61,46), light=Color.rgb(246,249,247);
    String token="", role="student", userId="";

    @Override public void onCreate(Bundle b){super.onCreate(b);showLogin();}

    TextView title(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(green);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(20,18,20,12);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);return b;}
    void base(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(light);ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(18,12,18,30);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    void msg(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    void showLogin(){
        base();content.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView h=title("MADARSA MANAGEMENT",28);h.setGravity(Gravity.CENTER);content.addView(h);
        TextView sub=title("Supabase-connected • Islamic • Academic • Administration",14);sub.setGravity(Gravity.CENTER);content.addView(sub);
        EditText email=new EditText(this);email.setHint("Email");email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);content.addView(email);
        EditText pass=new EditText(this);pass.setHint("Password");pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);content.addView(pass);
        Button login=btn("Login");content.addView(login);
        Button signup=btn("Create Account");content.addView(signup);
        TextView note=title("Your records are stored online in Supabase. Never put a service-role key in the app.",12);note.setGravity(Gravity.CENTER);content.addView(note);
        login.setOnClickListener(v->doLogin(email.getText().toString().trim(),pass.getText().toString()));
        signup.setOnClickListener(v->showSignup());
    }
    void doLogin(String email,String pass){
        if(email.isEmpty()||pass.isEmpty()){msg("Email and password required.");return;}
        msg("Connecting to Supabase...");
        ExecutorService ex=Executors.newSingleThreadExecutor();
        ex.execute(()->{try{
            SupabaseClient.AuthResult r=SupabaseClient.login(email,pass);
            if(!r.ok){runOnUiThread(()->msg(r.message));return;}
            token=r.accessToken;userId=r.userId;JSONObject p=SupabaseClient.getProfile(token);role=p.optString("role","student");
            runOnUiThread(()->showPortals(p.optString("full_name","User"),role));
        }catch(Exception e){runOnUiThread(()->msg("Connection error: "+e.getMessage()));}finally{ex.shutdown();}});
    }
    void showSignup(){
        base();content.addView(title("Create Account",25));
        EditText name=new EditText(this);name.setHint("Full Name");content.addView(name);
        EditText email=new EditText(this);email.setHint("Email");content.addView(email);
        EditText pass=new EditText(this);pass.setHint("Password (6+ characters)");pass.setInputType(0x81);content.addView(pass);
        Button create=btn("Create Account");content.addView(create);Button back=btn("Back to Login");content.addView(back);
        create.setOnClickListener(v->{if(name.getText().toString().trim().isEmpty()||email.getText().toString().trim().isEmpty()||pass.length()<6){msg("Enter name, email and a 6+ character password.");return;}ExecutorService ex=Executors.newSingleThreadExecutor();ex.execute(()->{try{SupabaseClient.AuthResult r=SupabaseClient.signUp(email.getText().toString().trim(),pass.getText().toString(),name.getText().toString().trim());runOnUiThread(()->msg(r.message));}catch(Exception e){runOnUiThread(()->msg("Connection error: "+e.getMessage()));}finally{ex.shutdown();}});});
        back.setOnClickListener(v->showLogin());
    }
    void showPortals(String name,String userRole){
        base();content.addView(title("Welcome, "+name,25));content.addView(title("Account role: "+userRole,14));
        if(userRole.equals("admin")){Button a=btn("Admin Portal");content.addView(a);a.setOnClickListener(v->admin());}
        if(userRole.equals("staff")||userRole.equals("teacher")){Button s=btn("Staff / Teacher Portal");content.addView(s);s.setOnClickListener(v->staff());}
        if(userRole.equals("student")||userRole.equals("parent")){Button st=btn("Student Portal");content.addView(st);st.setOnClickListener(v->student());}
        Button out=btn("Logout");content.addView(out);out.setOnClickListener(v->{token="";showLogin();});
    }
    void header(String name,String r){content.addView(title(name,25));content.addView(title(r,14));Button home=btn("← Portal Home");content.addView(home);home.setOnClickListener(v->showPortals("User",role));}
    void card(String h,String b){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(10,8,10,14);c.addView(title(h,18));TextView x=title(b,14);x.setTextColor(Color.DKGRAY);c.addView(x);content.addView(c);}
    void admin(){base();header("Admin Dashboard","Full management control");card("Connected","Supabase database is connected. The database now contains students, staff, classes, attendance, Hifz, exams, results, fees, payroll, notices and permissions modules.");String[] items={"Students","Staff & Teachers","Classes & Sections","Subjects","Academic Years","Student Attendance","Staff Attendance","Daily Reports","Hifz Tracking","Leave Requests","Exams & Results","Timetable","Notices & Announcements","Payroll & Salary Deduction","Staff Permissions","Activity Logs","Madarsa Settings","Help Centre"};for(String x:items){Button b=btn(x);content.addView(b);b.setOnClickListener(v->adminDetail(((Button)v).getText().toString()));}}
    void adminDetail(String x){base();header(x,"Admin");card(x,"This module is ready for database integration. Records will be managed in Supabase.");Button back=btn("Back to Admin Dashboard");content.addView(back);back.setOnClickListener(v->admin());}
    void staff(){base();header("Staff Dashboard","Teacher / Staff");String[] items={"My Attendance","My Assigned Class","Mark Student Attendance","Update Daily Report","Update Hifz Tracking","Student List","Notices","Timetable","Leave Request","My Profile"};for(String x:items){Button b=btn(x);content.addView(b);b.setOnClickListener(v->staffDetail(((Button)v).getText().toString()));}}
    void staffDetail(String x){base();header(x,"Staff");card(x,"Supabase-connected module. Your permitted records will be loaded here.");Button back=btn("Back");content.addView(back);back.setOnClickListener(v->staff());}
    void student(){base();header("Student Dashboard","Student Portal");String[] items={"My Attendance Analysis","Request for Leave","Daily Report Analysis","Hifz Tracking","Results Analysis","Notices & Announcements","Timetable","My Profile"};for(String x:items){Button b=btn(x);content.addView(b);b.setOnClickListener(v->studentDetail(((Button)v).getText().toString()));}}
    void studentDetail(String x){base();header(x,"Student");card(x,"Your private records are protected by Supabase Row Level Security.");Button back=btn("Back");content.addView(back);back.setOnClickListener(v->student());}
}